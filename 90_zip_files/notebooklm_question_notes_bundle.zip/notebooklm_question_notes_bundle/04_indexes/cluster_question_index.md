# Cluster question index

| Cluster ID | Question ID | Expected answer type | Use | Question |
|---|---|---|---|---|
| C1 | [[C1_Q01]] | Definition block | Conceptual glossary | Across PDF009–PDF011, what is the cleanest definition of the difference between wealth and productive capital? |
| C1 | [[C1_Q02]] | Mechanism paragraph | Core synthesis | How do capitalized land rents generate increases in measured wealth without expanding productive capacity? |
| C1 | [[C1_Q03]] | Bridge paragraph | Literature map | How does the wealth residual prepare the ground for the later land-bubble and credit-speculation papers? |
| C1 | [[C1_Q04]] | Warning list | Methods note | What measurement warnings should be carried into any empirical analysis of land, housing, or real estate wealth? |
| C1 | [[C1_Q05]] | Critical translation | Theory bridge | What elements of Stiglitz’s rent framework are closest to heterodox rent/financialization language? |
| C2 | [[C2_Q01]] | Plain-language explanation | Core synthesis | What is the minimal explanation of wobbly dynamics suitable for investigators who do not work on nonlinear OLG theory? |
| C2 | [[C2_Q02]] | Comparative mechanism | Literature map | How does the introduction of land change the baseline wobbly economy relative to the no-land model? |
| C2 | [[C2_Q03]] | Definition + mechanism | Conceptual glossary | What are phase transitions and why do they matter for real-estate boom-bust cycles? |
| C2 | [[C2_Q04]] | Mechanism paragraph | Core synthesis | How does land speculation crowd out capital accumulation in dynamic terms? |
| C2 | [[C2_Q05]] | Prioritization | Workflow control | Which parts of the wobbly-dynamics cluster are essential for the final memo and which are background? |
| C3 | [[C3_Q01]] | Mechanism distinction | Core synthesis | What is the difference between aggregate credit expansion and sectoral credit expansion in the Hirano-Stiglitz credit papers? |
| C3 | [[C3_Q02]] | Causal chain | Core synthesis | How exactly does credit to real estate or lower real-estate collateral requirements inflate land prices? |
| C3 | [[C3_Q03]] | Conditions list | Formal result | Under what conditions does credit expansion crowd out productive capital rather than crowding it in? |
| C3 | [[C3_Q04]] | Policy mechanism | Policy note | How do low interest rates operate when land is an alternative store of value besides money and capital? |
| C3 | [[C3_Q05]] | Evidence inventory | Evidence note | What empirical literature is mobilized on real-estate credit versus manufacturing credit and productivity growth? |
| C3 | [[C3_Q06]] | Temporal distinction | Core synthesis | How should the review separate short-run asset booms from long-run growth effects? |
| C4 | [[C4_Q01]] | Cross-paper theorem map | Core synthesis | What is the conceptual and formal relation between unbalanced growth and land bubbles/overvaluation across PDF008, PDF001, and PDF012? |
| C4 | [[C4_Q02]] | Comparative theorem note | Formal result | How does the Land Overvaluation Theorem differ from leverage-driven bubble necessity? |
| C4 | [[C4_Q03]] | Parameter map | Formal result | What roles are played by elasticity of substitution, differential productivity growth, and leverage thresholds? |
| C4 | [[C4_Q04]] | Glossary | Conceptual glossary | How should the memo distinguish land overvaluation, rational bubble, asset bubble, and observed housing-price inflation? |
| C4 | [[C4_Q05]] | Measurement warning | Methods note | What does the Toda rent-yield note imply about empirical measures using housing rents instead of pure land rents? |
| C5 | [[C5_Q01]] | Baseline reconstruction | Core synthesis | What is the standard land-economy argument that R>G blocks infinite debt rollover? |
| C5 | [[C5_Q02]] | Mechanism paragraph | Core synthesis | How does unbalanced growth reopen the possibility of debt rollover in an economy with land? |
| C5 | [[C5_Q03]] | Formal explanation | Formal result | How can land bubbles coexist with Pareto efficiency in these models? |
| C5 | [[C5_Q04]] | Critical comparison | Literature map | What exactly is wrong with applying the Diamond landless rollover intuition to an economy with land? |
| C5 | [[C5_Q05]] | Version-control note | Workflow control | Which version, PDF002 or PDF014, should be treated as the main source for the final memo? |
| C6 | [[C6_Q01]] | Policy synthesis | Policy note | How can the Henry George policy article be used as the policy-facing synthesis of the whole branch? |
| C6 | [[C6_Q02]] | Policy inventory | Policy note | What regulatory tools appear across the corpus: land taxation, capital-gains taxation, financial regulation, collateral rules, public investment? |
| C6 | [[C6_Q03]] | Critical limitation | Critique | What assumptions are too abstract for direct application to Latin America, especially ownership structures, credit systems, urban land-use regimes, and peripheral external constraints? |
| C6 | [[C6_Q04]] | Fondecyt translation | Project synthesis | How can the corpus be translated into the project language of land usage, localization rents, and financialization in Latin America? |
| C6 | [[C6_Q05]] | Gap map | Research extension | What alternative theoretical literatures should be added later to avoid a purely neoclassical/OLG framing of land rent? |
| C6 | [[C6_Q06]] | Outline request | Deliverable design | What is the final 5–15 page memo architecture that emerges from these clusters? |